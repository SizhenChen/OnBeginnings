$(document).ready(function() {$("#rectangle").hide(); })




function zoomOut() {
    document.getElementById("text1").style.visibility = "hidden";
    $(document).ready(function() {$("#rectangle").show(); });
    document.getElementById("rectangle").style.animation = "Zoom 3s";   
    }                                                            


if (zoomOut()){
}

